import UIKit

//Система запуска корабля на межзведный полет
protocol Command {
    func execute()
}

final class EngineThird {
    private let power: Double = 0.90
    
    func switchOn() {
        print("Engine's switched on")
    }
    
    func switchOff() {
        print("Engine's switched off")
    }
}

final class HeatingCoolingFuselage {
    var temperature: Double = 200
    let safeTemperature: Double = -10
    var mode: String {
        return temperature > safeTemperature ? "cooling" : "heating"
    }
    
    func start() {
        print("Start \(mode) the fuselage")
    }
    
    func stop() {
        print("Start \(mode) the fuselage")
    }
}

final class SwitchOnCommand: Command {
    var engine: EngineThird
    
    init(engine: EngineThird) {
        self.engine = engine
    }
    
    func execute() {
        engine.switchOn()
    }
}

final class StartTemperatureCommand: Command {
    var heater: HeatingCoolingFuselage
    
    init(heater: HeatingCoolingFuselage) {
        self.heater = heater
    }
    
    func execute() {
        if heater.temperature < -10 {
            heater.temperature = -10
        }
        heater.start()
    }
}

final class Programm {
    var commands: [Command] = []
    
    func start() {
        commands.forEach { $0.execute() }
    }
}

let engine = EngineThird()
let heaterAndColler = HeatingCoolingFuselage()

let engineOnCommand = SwitchOnCommand(engine: engine)
let temperatureCommand = StartTemperatureCommand(heater: heaterAndColler)

let starFlight = Programm()
starFlight.commands.append(engineOnCommand)
starFlight.commands.append(temperatureCommand)
starFlight.start()
